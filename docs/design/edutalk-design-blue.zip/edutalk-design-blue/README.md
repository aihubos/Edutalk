# EDU톡 모바일 시안 (토스 블루) · 코드 이식용 원본

홈·기관찾기·기관 상세 3개 화면과 디자인 기준 보드의 원본입니다. 모든 기관·후기·점수·비용은 체험용 예시이며, 실제 기관 정보나 인증 결과가 아닙니다.

## 구성

| 경로 | 내용 |
|---|---|
| `design/Main.dc.html` | 01 홈. 두 경로 탭(교육자 일터 기본), 검색, 지역 칩, 역할별 목록 |
| `design/Discover.dc.html` | 02 기관찾기. 검색·지역·유형·정렬 7종·관심·비교 최대 3곳 |
| `design/Institution.dc.html` | 03 기관 상세. 신뢰 카드, 역할별 평가 탭, 외부 후기 링크, 비용·셔틀·모집·프로그램, 하단 행동 바 |
| `design/Guide.dc.html` | 디자인 기준 보드 (1200px 고정) |
| `design/canvas.json` | 캔버스 배치 정보 |
| `css/edutalk-mobile.css` | DESIGN.md 토큰 + 시안 컴포넌트를 클래스(`et-*`)로 옮긴 이식용 CSS |

## `.dc.html` 읽는 법

시안 파일은 Claude Design 캔버스 형식이라 브라우저에서 바로 열면 템플릿 문법이 그대로 보입니다. 레이아웃·색·간격은 각 요소의 인라인 `style`에 그대로 있으니 참고용 원본으로 쓰세요.

| 시안 문법 | React/Next.js 대응 |
|---|---|
| `{{value}}` | `{value}` |
| `<sc-for list="{{rows}}" as="it">` | `rows.map((it) => …)` |
| `<sc-if value="{{cond}}">` | `{cond && …}` |
| `onClick="{{fn}}"` | `onClick={fn}` |
| 파일 하단 `class Component` 의 `renderVals()` | 컴포넌트의 상태·파생값 계산 |
| `<a href="Discover.dc.html">` | `<Link href="/discover">` |

## 색 사용 규칙

- `#3182F6` (primary): 포커스 링, 평점 막대, 아이콘, 선택 테두리 같은 비텍스트 요소
- `#1B64DA` (primary-strong): 흰 글자 버튼 배경, 링크·선택 글자. 흰 바탕 위 `#3182F6` 글자는 약 3.7:1로 16px 본문 기준 4.5:1에 못 미쳐서 구분했습니다.
- `#071A52` (navy): 워드마크, 강조 점수, 비교함 바
- `#FFF8E1` / `#8A5A00`: 체험용 배지와 주의 안내
- `#B4232C`: 관심(하트) 활성 상태

## 글꼴

`Pretendard Variable → Pretendard → SUIT Variable → Apple SD Gothic Neo → Noto Sans KR → system-ui` 순서입니다. 시안 캔버스는 웹폰트를 따로 불러오지 않고 기기에 설치된 글꼴로 표시합니다. 앱에서는 기존 방식대로 Pretendard를 로드하세요.

## 시안에서 동작하지 않는 것

전화, 길찾기, 공유, 외부 후기 링크, 관심·비교 저장, 비교 화면, 검색 조건 저장, 순위·튜터·MY 탭은 시안에서 안내 문구만 보여줍니다. 실제 API 호출은 없습니다. 통학차량·체험수업은 목록 필터로 넣지 않았고, 상세 화면에서 출처·확인일과 함께 표시합니다.
